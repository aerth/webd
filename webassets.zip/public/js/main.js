/* eslint-env jquery, browser */
$(document).ready(() => {

  const urlParams = new URLSearchParams(window.location.search);
  const error = urlParams.get('error');
  if (error != null && error.length != 0){
    console.log("error:", error);
    document.getElementById('errorText').innerHTML = "Error: " + error;
  }


});
